<?php
$conn= new mysqli('localhost','id18855734_administrator','Firefox@1234','id18855734_quizdb');


?>